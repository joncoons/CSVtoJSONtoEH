Azure Function using the Blob Trigger to transform a CSV, line by line, into JSON, and push each message into an Event Hub.
